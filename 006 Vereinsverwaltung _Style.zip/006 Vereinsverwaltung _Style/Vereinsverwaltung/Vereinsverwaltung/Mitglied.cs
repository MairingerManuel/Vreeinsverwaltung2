﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Vereinsverwaltung
{
    class Mitglied
    {
        public string Nachname { get; set; }
        public string Vorname { get; set; }
        public string Geburtsdatum { get; set; }
    }
}
