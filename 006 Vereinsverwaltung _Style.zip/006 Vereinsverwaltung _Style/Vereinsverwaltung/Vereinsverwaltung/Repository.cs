﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.CompilerServices;
using System.Text;

namespace Vereinsverwaltung
{
    class Repository
    {
        private const string fileName = "Mitglied.csv";

        private static Repository instance;

        List<Mitglied> mitglieds;

        private Repository()
        {
            mitglieds = new List<Mitglied>();
            LoadCdsFromCsv();
        }

        public static Repository GetInstance()
        {
            if (instance == null)
                instance = new Repository();

            return instance;
        }


        private void LoadCdsFromCsv()
        {
            string[][] cdCsv = fileName.ReadStringMatrixFromCsv(true);
            mitglieds = cdCsv.GroupBy(line => new { Nachname = line[0], Vorname = line[1], Geburtsdatum = line[2] }).Select(x =>
                new Mitglied
                {
                    Nachname = x.Key.Nachname,
                    Vorname = x.Key.Vorname,
                    Geburtsdatum = x.Key.Geburtsdatum
                }).ToList();
        }

   
        public void AddMg(Mitglied mitglied)
        {
            mitglied.Add(mitglied);
        }

        public List<Mitglied> GetAllMg()
        {
            return mitglieds.OrderBy(x => x.Nachname).ThenBy(x => x.Vorname).ToList(); //Erstellt neue Liste!
        }
    }
}

