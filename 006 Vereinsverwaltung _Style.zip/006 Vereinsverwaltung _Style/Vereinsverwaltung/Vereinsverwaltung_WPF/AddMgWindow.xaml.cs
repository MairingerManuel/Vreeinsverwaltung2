﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace Vereinsverwaltung_WPF
{
    /// <summary>
    /// Interaction logic for AddMgWindow.xaml
    /// </summary>
    public partial class AddMgWindow : Window
    {
        public AddMgWindow()
        {
            InitializeComponent();
            Loaded += new RoutedEventHandler(AddMgWindow_loaded);
        }

        void AddMgWindow_loaded(object sender, RoutedEventArgs e)
        {
            btsave.Click += new RoutedEventHandler(btsave_Click);
            btCancel.Click += new RoutedEventHandler(btCancel_Click);
        }

        void btCancel_Click(object sender, RoutedEventArgs e)
        {
            Close();
        }

        void btsave_Click(object sender, RoutedEventArgs e)
        {
            Mitglied newMg = new Mitglied();
            newMg.Nachname = tbNachname.Text;
            newMg.Vorname = tbVorname.Text;
            newMg.Geburtsdatum = tbGeburtsdatum;
            Repository.GetInstance().AddMg(newMg);
            Close();
        }
    }
}
